#undef explicit_bzero
void explicit_bzero(void *, size_t);
